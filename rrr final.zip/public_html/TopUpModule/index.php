<?php

// Basic Autoloader
spl_autoload_register(function ($class) {
    // Prefix: App\ -> src/
    $prefix = 'App\\';
    $base_dir = __DIR__ . '/src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

require_once __DIR__ . '/src/Helpers/functions.php';

use App\Services\OrderService;
use App\Services\DepositService;

// Start Session
session_start();

// Mock User Login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1; // Assume user ID 1 exists
}

$action = $_GET['action'] ?? 'home';

echo "<h1>TopUp Module (Plain PHP)</h1>";
echo "<nav><a href='?action=home'>Home</a> | <a href='?action=test_order'>Test Order</a> | <a href='?action=test_deposit'>Test Deposit</a></nav><hr>";

try {
    switch ($action) {
        case 'home':
            echo "<p>Welcome. User ID: " . user_id() . "</p>";
            break;

        case 'test_order':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $service = new OrderService();
                $result = $service->addOrder($_POST);
                echo "<pre>" . print_r($result, true) . "</pre>";
                if (isset($result['redirect_url'])) {
                    echo "<a href='{$result['redirect_url']}'>Proceed to Payment</a>";
                }
            } else {
                ?>
                <h3>Place Order</h3>
                <form method="POST">
                    Variation ID: <input type="number" name="variation_id" value="1"><br>
                    Quantity: <input type="number" name="quantity" value="1"><br>
                    Payment Method:
                    <select name="payment_method">
                        <option value="uddoktapay">Online Payment (UddoktaPay)</option>
                        <option value="wallet">Wallet</option>
                    </select><br>
                    Account Info: <input type="text" name="account_info" placeholder="Player ID"><br>
                    <button type="submit">Order</button>
                </form>
                <?php
            }
            break;

        case 'test_deposit':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $service = new DepositService();
                $result = $service->addFund($_POST);
                echo "<pre>" . print_r($result, true) . "</pre>";
                if (isset($result['redirect_url'])) {
                    echo "<a href='{$result['redirect_url']}'>Proceed to Payment</a>";
                }
            } else {
                ?>
                <h3>Add Deposit</h3>
                <form method="POST">
                    Amount: <input type="number" name="amount" value="100"><br>
                    <button type="submit">Deposit</button>
                </form>
                <?php
            }
            break;

        case 'order_ipn':
            // Simulate IPN callback or handling return
            // In real scenario, this is POST from Gateway
            // Here we just catching return from gateway redirect
            echo "<h3>Order IPN / Return</h3>";
            echo "<pre>Request: " . print_r($_REQUEST, true) . "</pre>";
            // Logic to verify logic would be called here if we had valid transaction_id
            break;

        case 'deposit_ipn':
            echo "<h3>Deposit IPN / Return</h3>";
            echo "<pre>Request: " . print_r($_REQUEST, true) . "</pre>";
            break;

        default:
            echo "404 Not Found";
    }
} catch (Exception $e) {
    echo "<div style='color:red'>Error: " . $e->getMessage() . "</div>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
