<?php

namespace App\Constants;

class OrderStatus
{
    const PENDING = 0;
    const PROCESSING = 1;
    const COMPLETED = 2;
    const CANCELLED = 3;
    const AUTOPROCESSING = 4; // Check logic
}
