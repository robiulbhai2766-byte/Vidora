<?php

namespace App\Constants;

class Role
{
    const USER = 0;
    const ADMIN = 1;
    const RESELLER = 2; // Assuming
}
