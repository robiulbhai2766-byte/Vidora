<?php

namespace App\Constants;

class Status
{
    const ENABLE = 1;
    const DISABLE = 0;

    const ACTIVE = 1;
    const INACTIVE = 0;

    const YES = 1;
    const NO = 0;

    const UNPAID = 0;
    const PAID = 1;
    const PROCESSING = 2;
    const COMPLETED = 3;
    const REJECTED = 4;
    const CANCELLED = 5;

    const VOUCHER = 1;
    const TOPUP = 2;
    const INGAME = 3;

    const AVAILABLE = 1;
    const SOLD = 2;

    const WALLET = 'wallet';

    const CREDIT = '+';
    const DEBIT = '-';
}
