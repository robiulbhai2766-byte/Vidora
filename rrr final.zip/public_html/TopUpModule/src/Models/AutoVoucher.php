<?php

namespace App\Models;

use App\Core\Model;

class AutoVoucher extends Model
{
    protected $table = 'auto_vouchers';
}
