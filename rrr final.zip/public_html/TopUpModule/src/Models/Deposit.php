<?php

namespace App\Models;

use App\Core\Model;

class Deposit extends Model
{
    protected $table = 'deposits';

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
