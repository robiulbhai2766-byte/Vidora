<?php

namespace App\Models;

use App\Core\Model;
use App\Constants\Status; // Placeholder if needed

class Order extends Model
{
    protected $table = 'orders';

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function variation()
    {
        return $this->belongsTo(Variation::class, 'variation_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function isPending()
    {
        // Assuming 0 or 1 for status, checking typical logic
        return isset($this->attributes['status']) && $this->attributes['status'] == 0; // Adjust constant based on Service
    }
}
