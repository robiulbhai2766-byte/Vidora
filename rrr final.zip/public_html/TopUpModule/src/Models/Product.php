<?php

namespace App\Models;

use App\Core\Model;
use App\Constants\Status;

class Product extends Model
{
    protected $table = 'products';

    public function isVoucher()
    {
        return isset($this->attributes['type']) && $this->attributes['type'] == 'voucher'; // Verify constant
    }

    public function isTopup()
    {
        return isset($this->attributes['type']) && $this->attributes['type'] == 'topup'; // Verify constant
    }
}
