<?php

namespace App\Models;

use App\Core\Model;

class User extends Model
{
    protected $table = 'users';

    public function isReseller()
    {
        return isset($this->attributes['role']) && $this->attributes['role'] == 'reseller'; // Example logic
    }
}
