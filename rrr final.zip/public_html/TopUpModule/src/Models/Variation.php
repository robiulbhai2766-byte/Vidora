<?php

namespace App\Models;

use App\Core\Model;

class Variation extends Model
{
    protected $table = 'variations';

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    public function vouchers()
    {
        return $this->hasMany(Voucher::class, 'variation_id');
    }

    public function isAutomatic()
    {
        return isset($this->attributes['is_automatic']) && $this->attributes['is_automatic'];
    }
}
