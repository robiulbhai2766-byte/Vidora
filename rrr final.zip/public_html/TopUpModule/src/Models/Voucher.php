<?php

namespace App\Models;

use App\Core\Model;

class Voucher extends Model
{
    protected $table = 'vouchers';
}
