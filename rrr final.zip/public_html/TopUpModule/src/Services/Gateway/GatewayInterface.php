<?php

namespace App\Services\Gateway;

use App\Models\Order;
use App\Models\Deposit;
use Exception; // Standard Exception

interface GatewayInterface
{
    public static function prepareDepositData(Deposit $deposit, $gateway); // Removed return type hint for compatibility
    public static function depositIpn($request, Deposit $deposit, $gateway);
    public static function prepareOrderData(Order $order, $gateway);
    public static function orderIpn($request, Order $order, $gateway);
}
