<?php if (isset($_SESSION['admin_id'])): ?>
    </div> <!-- End Main Content -->
<?php endif; ?>

</body>

</html>
