<?php
function renderPagination($currentPage, $totalRecords, $limit, $baseUrl)
{
    $totalPages = ceil($totalRecords / $limit);
    if ($totalPages <= 1)
        return; // No pagination needed

    // Check if URL already has parameters
    $separator = (strpos($baseUrl, '?') === false) ? '?' : '&';

    echo '<div class="pagination-container" style="display:flex; gap:5px; justify-content:center; margin-top:20px;">';

    // Previous Button
    if ($currentPage > 1) {
        echo '<a href="' . $baseUrl . $separator . 'page=' . ($currentPage - 1) . '" class="pagination-btn">&laquo; Prev</a>';
    } else {
        echo '<span class="pagination-btn disabled">&laquo; Prev</span>';
    }

    // Numbered Links
    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);

    if ($start > 1) {
        echo '<a href="' . $baseUrl . $separator . 'page=1" class="pagination-btn">1</a>';
        if ($start > 2)
            echo '<span class="pagination-dots">...</span>';
    }

    for ($i = $start; $i <= $end; $i++) {
        $active = ($i == $currentPage) ? 'active' : '';
        echo '<a href="' . $baseUrl . $separator . 'page=' . $i . '" class="pagination-btn ' . $active . '">' . $i . '</a>';
    }

    if ($end < $totalPages) {
        if ($end < $totalPages - 1)
            echo '<span class="pagination-dots">...</span>';
        echo '<a href="' . $baseUrl . $separator . 'page=' . $totalPages . '" class="pagination-btn">' . $totalPages . '</a>';
    }

    // Next Button
    if ($currentPage < $totalPages) {
        echo '<a href="' . $baseUrl . $separator . 'page=' . ($currentPage + 1) . '" class="pagination-btn">Next &raquo;</a>';
    } else {
        echo '<span class="pagination-btn disabled">Next &raquo;</span>';
    }

    echo '</div>';

    // Add embedded CSS for simplicity
    echo '
    <style>
        .pagination-btn {
            display: inline-block;
            padding: 8px 12px;
            border: 1px solid #ddd;
            background: #fff;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }
        .pagination-btn:hover:not(.disabled) {
            background: #f0f0f0;
        }
        .pagination-btn.active {
            background: var(--primary, #007bff);
            color: white;
            border-color: var(--primary, #007bff);
        }
        .pagination-btn.disabled {
            color: #aaa;
            cursor: not-allowed;
            background: #f9f9f9;
        }
        .pagination-dots {
            padding: 8px;
            color: #777;
        }
    </style>
    ';
}
?>