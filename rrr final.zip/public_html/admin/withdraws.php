<?php
require_once '../config/db.php';
require_once 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $act = $_POST['action'] ?? '';
    $id = $_POST['trx_id'] ?? 0;
    $uid = $_POST['user_id'] ?? null;
    $amount = $_POST['amount'] ?? 0;

    if ($act === 'approve') {
        // Just Mark Approved (Balance already deducted when request made)
        $stmt = $pdo->prepare("UPDATE transactions SET status = 'approved' WHERE id = ?");
        $stmt->execute([$id]);
    } elseif ($act === 'reject') {
        // Refund Balance
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE transactions SET status = 'rejected' WHERE id = ?");
        $stmt->execute([$id]);

        $stmt = $pdo->prepare("UPDATE users SET balance_winning = balance_winning + ? WHERE id = ?");
        $stmt->execute([$amount, $uid]);
        $pdo->commit();
    }
}

$pending = $pdo->query("SELECT t.*, u.name, u.phone FROM transactions t JOIN users u ON t.user_id = u.id WHERE t.type='withdraw' AND t.status='pending'")->fetchAll();
?>

<div class="header-bar">
    <h2 class="page-title">Withdraw Requests</h2>
</div>

<div class="panel">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Account No</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pending as $p): ?>
                    <tr>
                        <td>#
                            <?php echo $p['id']; ?>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($p['name']); ?>
                            <br><small>
                                <?php echo htmlspecialchars($p['phone']); ?>
                            </small>
                        </td>
                        <td style="color:red; font-weight:bold;">৳
                            <?php echo $p['amount']; ?>
                        </td>
                        <td>
                            <?php echo $p['method']; ?>
                        </td>
                        <td>
                            <?php echo $p['account_number']; ?>
                        </td>
                        <td>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Confirm payment sent?')">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="trx_id" value="<?php echo $p['id']; ?>">
                                <button class="action-btn btn-green">Paid</button>
                            </form>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('Reject and Refund?')">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="trx_id" value="<?php echo $p['id']; ?>">
                                <input type="hidden" name="user_id" value="<?php echo $p['user_id']; ?>">
                                <input type="hidden" name="amount" value="<?php echo $p['amount']; ?>">
                                <button class="action-btn btn-red">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php if (empty($pending))
            echo "<p style='padding:15px; text-align:center;'>No pending withdraws.</p>"; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
