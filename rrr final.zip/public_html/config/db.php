<?php
$host = 'localhost';
$db = 'frgtourb_pro';
$user = 'frgtourb_pro';
$pass = 'frgtourb_pro'; // Trailing space removed

$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // On shared hosting, you must create the database manually in the Control Panel.
    // The script cannot create it for you.
} catch (\PDOException $e) {
    if (isset($suppress_db_die) && $suppress_db_die === true) {
        $pdo = null;
        // Optionally log the error
    } else {
        // Show a cleaner error message for debugging
        die("Database Connection Failed: " . $e->getMessage());
    }
}
?>