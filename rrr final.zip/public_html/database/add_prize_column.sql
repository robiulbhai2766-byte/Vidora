ALTER TABLE `matches` ADD COLUMN `prize_description` TEXT DEFAULT NULL AFTER `prize_pool`;
