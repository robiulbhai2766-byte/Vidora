ALTER TABLE `participants`
ADD COLUMN `kills` INT(11) DEFAULT 0 AFTER `game_username`,
ADD COLUMN `win_amount` DECIMAL(10,2) DEFAULT 0.00 AFTER `kills`;
