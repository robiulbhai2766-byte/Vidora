ALTER TABLE `matches` ADD COLUMN `redirect_url` VARCHAR(255) DEFAULT NULL AFTER `image_url`;
