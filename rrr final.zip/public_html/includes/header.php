<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Expects $pageTitle to be set before including
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo isset($pageTitle) ? $pageTitle : (getSetting('app_name') ?: 'RRR Esports'); ?>
    </title>
    <link rel="icon" type="image/png" href="<?php echo getSetting('favicon'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <header>
        <div class="logo" onclick="window.location.href='index.php'">
            <!-- Ideally fetch from DB/Settings -->
            <img id="header-app-icon"
                src="<?php echo getSetting('app_logo') ?: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg2v5v5v5v5v5v5/s1600/rrr-esports-logo.png'; ?>"
                alt="Logo">
            <span class="logo-text"><?php echo getSetting('app_name') ?: 'FRG TOUR BD'; ?></span>
        </div>

        <div class="header-right">
            <button class="theme-btn" onclick="toggleUserTheme()" id="header-theme-btn">
                <i class="fas fa-moon"></i>
            </button>

            <?php if (isset($_SESSION['user_id'])): ?>
                <?php
                // Force-update balance from DB to ensure validity
                try {
                    $stmt = $pdo->prepare("SELECT balance_deposit, balance_winning FROM users WHERE id = ?");
                    $stmt->execute([$_SESSION['user_id']]);
                    $balData = $stmt->fetch();
                    if ($balData) {
                        $_SESSION['user_balance'] = $balData['balance_deposit'] + $balData['balance_winning'];
                    }
                } catch (Exception $e) {
                    // Silent fail, keep session value
                }
                ?>
                <!-- LOGGED IN USER NAV -->
                <div class="user-nav" style="display: flex;">
                    <div class="balance-pill" onclick="window.location.href='profile.php'">
                        <i class="fas fa-wallet"></i>
                        <span id="header-balance">
                            <?php echo number_format($_SESSION['user_balance'] ?? 0, 2); ?>
                        </span> ৳
                    </div>
                    <!-- Notification Badge -->
                    <div class="icon-btn" onclick="window.location.href='notifications.php'">
                        <i class="fas fa-bell"></i>
                        <div id="header-notif-badge" class="notif-badge">
                            <?php
                            // Simple fetch count for now
                            $count = $pdo->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
                            echo $count > 9 ? '9+' : $count;
                            ?>
                        </div>
                    </div>
                    <div class="icon-btn" onclick="toggleSidebar()" style="margin-left: 5px;">
                        <img src="<?php echo getSetting('default_avatar_url') ?: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'; ?>"
                            style="width:30px; height:30px; border-radius:50%; object-fit:cover;">
                    </div>
                </div>
            <?php else: ?>
                <!-- GUEST NAV -->
                <div class="auth-buttons">
                    <button class="btn-login-nav" onclick="window.location.href='login.php'">Login</button>
                    <button class="btn-reg-nav" onclick="window.location.href='register.php'">Register</button>
                </div>
            <?php endif; ?>
        </div>
    </header>

    <!-- SIDEBAR OVERLAY -->
    <div class="sidebar-overlay" onclick="closeAllSidebars()"></div>

    <!-- SIDEBAR -->
    <?php include 'sidebar.php'; ?>

    <main id="main-content">