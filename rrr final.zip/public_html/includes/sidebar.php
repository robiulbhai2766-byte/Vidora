<div class="sidebar" id="sidebar">
    <div class="sidebar-close" onclick="toggleSidebar()">×</div>
    <div class="sidebar-header">
        <img src="<?php echo getSetting('default_avatar_url') ?: 'https://cdn-icons-png.flaticon.com/512/149/149071.png'; ?>"
            class="sidebar-avatar">
        <div class="user-info">
            <?php if (isset($_SESSION['user_id'])): ?>
                <h4>
                    <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?>
                </h4>
                <p>
                    <?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>
                </p>
            <?php else: ?>
                <h4>Guest User</h4>
                <p>Please login</p>
            <?php endif; ?>
        </div>
    </div>
    <ul class="sidebar-menu">
        <li onclick="window.location.href='index.php'"><i class="fas fa-home"></i> Home</li>

        <?php if (isset($_SESSION['user_id'])): ?>
            <li onclick="window.location.href='profile.php'"><i class="fas fa-user"></i> My Account</li>
            <li onclick="window.location.href='my_matches.php'"><i class="fas fa-gamepad"></i> My Match</li>

            <li onclick="window.location.href='wallet.php?action=add'"><i class="fas fa-plus-circle"></i> Add Money</li>
            <li onclick="window.location.href='wallet.php?action=withdraw'"><i class="fas fa-minus-circle"></i> Withdraw
            </li>
            <li onclick="window.location.href='history.php'"><i class="fas fa-history"></i> History</li>
        <?php endif; ?>

        <li onclick="window.open('https://t.me/example', '_blank')"><i class="fab fa-telegram"></i> Join Telegram</li>
        <li onclick="window.location.href='contact.php'"><i class="fas fa-headset"></i> Support</li>

        <?php if (isset($_SESSION['user_id'])): ?>
            <li onclick="window.location.href='logout.php'" style="color:red; border-top:1px solid #eee; margin-top:10px;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </li>
        <?php else: ?>
            <div style="padding:15px;">
                <button class="primary-btn" onclick="window.location.href='login.php'">Login / Register</button>
            </div>
        <?php endif; ?>
    </ul>
</div>